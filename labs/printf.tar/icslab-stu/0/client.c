#include<stdio.h>
#include<string.h>
long long len;
char r[3000000];
int main()
{
    char s[30];
    long long port=0x0521; //the next port
    puts("Just get the port if you can.");
    while(1)
    {
        puts("-----------------------------------------------\nSay a word");
        memset(s,0,sizeof(s));
        memset(r,0,sizeof(r));
        fflush(stdout);
        len=read(0,&s,30);
        if(len<=20)
        {
            puts("The essence of human beings is REPEATER:");
            sprintf(r,s);   //instead of printf, I use sprintf to get a copy from output.
            printf("%s",r); //these two are equal to: printf(s)
            if(strcmp(r,s)!=0)
            {
                if(strcmp(r,"0x521\n")!=0)
                    puts("\nWhy make me an inferior repeater?\nDo you want to find something here?\nKeep going.\n");//if you exploit the vulnerability, you will see this.
                else
                {
                    printf("The port is %s",r);
                    puts("You have got the port.Just go to the next problem.");//if you get the port, you will see this.
                    return 0;
                }
            }
        }
        else
        {
            puts("len error(max length:20)");
            return 0;
        }
    }
}
