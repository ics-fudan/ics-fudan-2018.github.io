#include<string.h>
#include<stdio.h>
long long port=0;
int main()
{
    char s[300];
    memset(s,0,sizeof(s));
    long long ID=0xdeadbeef;//only in order to make you find it easier.
    /****IGNORE WHILE HACKING****/
    puts("input your student ID:");
    fflush(stdout);
    scanf("%lld",&ID);
    ID=ID%10000/1000*4096+ID%1000/100*256+ID%100/10*16+ID%10;
    printf("your cookie is %#llx(%1$lld)\n",ID);
    puts("Your goal is to make the flag equal to your cookie");
    puts("Enjoy yourself.");
    puts("---------------------------------------------------------");
    long long flag=0xdead;//only in order to make you find it easier.
    puts("There is a hint to make this problem easier:");
    printf("The address of flag is:\n%p\n",&flag);
    puts("---------------------------------------------------------");
    puts("welcome to the second system(also a repeater).");
    puts("Anything please.");
    /********STOP IGNORE*********/
    while(1)
    {
        memset(s,0,sizeof(s));
        fflush(stdout);
        int len=read(0,&s,0x100);
        if(len>100)
        {
            printf("len error(max length:100)");
            return 0;
        }
        puts("I'm a repeater, with no feeling:");
        printf(s);
        if(flag==ID)
        {
            printf("You open the door of a new problem.\nThe port is %lld.\n",port);
            return 0;
        }
        else
            puts("Ok,what's next?");
    }
}
