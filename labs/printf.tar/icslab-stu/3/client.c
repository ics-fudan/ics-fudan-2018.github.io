#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void sh()
{
    system("cat ./flag");
}
void welcome()
{
    puts("+------------------------------------------+");
    puts("|        Welcome to the book system        |");
    puts("+------------------------------------------|");
    puts("|  Find the flag from me to finish lab 3.  |");
    puts("+------------------------------------------+");
    puts("| It doesn't matter if you can't solve it. |");
    puts("+------------------------------------------+");
    puts("|   If you have any question about this,   |");
    puts("|you can ask me for help by wechat or other|");
    puts("+------------------------------------------+");
    puts("|           Wish you a good day.           |");
    puts("+------------------------------------------+");
    puts("");
    puts("");
}
int getint()
{
    fflush(stdout);
    int k=getchar();
    int ans=0;
    while(k!=EOF&(k<'0'||k>'9')) k=getchar();
    while(k>='0'&&k<='9') ans=ans*10+k-'0',k=getchar();
    return ans;
}
void show_booklist(char booklist[10][100])
{
    for(int i=0;i<10;i++)
        printf("%d.%s\n",i+1,booklist[i]);
}
int borrow_book(char booklist[10][100],int s)
{
    if(s<0||s>10)
    {
        puts("System Error:Unknown State.");
        puts("Shutdown....");
        exit(0);
    }
    if(s!=0)
    {
        puts("Failed...");
        puts("you have borrowed a book which name is:");
        printf(booklist[s-1]);
        puts("");
        return s;
    }
    else
    {
        show_booklist(booklist);
        puts("Please input the bookID you wanna borrow:");
        int bid=0;
        bid=getint();
        while(bid<1||bid>10)
        {
            puts("Please input a correct bookID.");
            bid=getint();
        }
        s=bid;
        puts("Sucess...");
        puts("You have borrowed a book which name is:");
        printf(booklist[s-1]);
        puts("");
        return s;
        
    }
}
int return_book(char booklist[10][100],int s)
{
    if(s<0||s>10)
    {
        puts("System Error:Unknown State.");
        puts("Shutdonw....");
        exit(0);
    }
    if(s!=0)
    {
        puts("Sucess.");
        puts("You have returned a book which name is:");
        printf(booklist[s-1]);
        puts("");
        s=0;
        return s;
    }
    else
    {
        puts("You didn't borow anything.");
        return s;
    }
}
void edit_profile(char profile[2][30])
{
    memset(profile[0],0,sizeof(profile[0]));
    memset(profile[1],0,sizeof(profile[1]));
    puts("Your Username(max-length:20):");
    fflush(stdout);
    int len=read(0,&profile[0],0x14);
    if(len>20)
    {
        puts("System Error:len error");
        puts("Shutdown....");
        exit(0);
    }
    puts("Your Password(max-length:20):");
    fflush(stdout);
    len=read(0,&profile[1],0x14);
    if(len>20)
    {
        puts("System Error:len error");
        puts("Shutdown....");
        exit(0);
    }
}
void show_profile(char profile[2][30])
{
    puts("Your Username:");
    printf(profile[0]);
    puts("");
    puts("Your Password:");
    printf(profile[1]);
    puts("");
}
void menu()
{
    char profile[2][30];
    char booklist[10][100]={\
        "The C Programming Language (Second Edition)",\
        "Computer Systems: A Programmer's Persective (Third Edition)",\
        "Logic and Computer Design Fundamentals (Fourth Edition)",\
        "Artificial Intelligence: A Guide to Intelligent Systems (Third Edition)",\
        "Computer Networking: A Top-Down Approach (Sixth Edition)",\
        "TCP/IP Illustrated: Volume 1: The Protocols",\
        "Introduction to Algorithms (Third Edition)",\
        "Data Structures and Algorithm Analysis in C (Second Edition)",\
        "Structure and Interpretation of Computer Programs (Second Edition)",\
        "Compilers: Principles, Techniques, & Tools (Second Edition)",\
    }; 
    puts("Please register first.");
    edit_profile(profile);
    int state=0;
    while(1)
    {
        puts("--------------------------------------------------------------------------------");
        puts("1.Show booklist");
        puts("2.Borrow a book");
        puts("3.Return a book");
        puts("4.Edit profile");
        puts("5.Show profile");
        puts("6.Quit system");
        printf(">>>");
        int opt;
        opt=getint();
        puts("--------------------------------------------------------------------------------");
        switch(opt)
        {
            case 1:
                show_booklist(booklist);
                break;
            case 2:
                state=borrow_book(booklist,state);
                break;
            case 3:
                state=return_book(booklist,state);
                break;
            case 4:
                edit_profile(profile);
                break;
            case 5:
                show_profile(profile);
                break;
            case 6:
                puts("Hope you find what you want.");
                return;
            default:
                puts("Error: option not found.");
        }
    }

}
int main()
{
    welcome();
    menu();
    return 0;
}
